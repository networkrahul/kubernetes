#!/bin/bash
echo "Ensure you are logged in as root"
sleep 3
echo "Turn Off Swap"
swapoff -a
echo "Install docker"
./docker.sh
echo "Check docker version -> ensure"
docker version
sleep 2
echo "Install k8s"
./k8s.sh
echo "Check kubctl version -> should show client version only"
kubectl version
sleep 2
echo "*******"
echo "Init master node -> Grab this OUTPUT for LATER USE -> VERY IMPORTANT"
echo "*******"
kubeadm init --pod-network-cidr=192.168.0.0/16
sleep 2
echo "Creating normal user called 'master' and logging in as 'master'"
./create_masteruser.sh
echo "*******"
echo "IMPORTANT: Logging in as new user 'master' - Run script ./as_masteruser.sh"
echo "*******"
su - master
