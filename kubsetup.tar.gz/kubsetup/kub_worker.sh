#!/bin/bash
echo "Ensure you are logged in as root"
sleep 3
echo "Turn Off Swap"
swapoff -a
echo "Install docker"
./docker.sh
echo "Check docker version -> ensure"
docker version
sleep 2
echo "Install k8s"
./k8s.sh
echo "Check kubctl version -> should show client version only"
kubectl version
echo "*******"
echo "IMPORTANT -> Now on this node, issue the 'kubeadm join ...' command that you should COPY from the output of 'kubadmin init ...' command executed on master node as part of script running on master"
echo "After running that command issue 'watch kubctl get nodes -o wide' on master to check until all worker nodes are in READY state => After that your cluster is READY"
echo "*******"
