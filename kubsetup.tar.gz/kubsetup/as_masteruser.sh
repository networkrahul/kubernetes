#!/bin/bash
echo "Copying kube config"
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
echo "Install CNI Calico"
set -x
kubectl create -f https://docs.projectcalico.org/manifests/tigera-operator.yaml
kubectl create -f https://docs.projectcalico.org/manifests/custom-resources.yaml
set +x
sleep 1
echo "Wait until each pod has status RUNNING"
watch kubectl get pods -n calico-system
echo "Untaint master so that we can run workloads on master"
sleep 1
kubectl taint nodes --all node-role.kubernetes.io/master-
sleep 1
echo "Confirm using this command if master is READY -> 'kubectl get nodes -o wide'"
kubectl get nodes -o wide
echo "*******"
echo "If not already run, then run ./kub_worker.sh on each worker node to join the cluster and follow further instructions there"
echo "*******"
