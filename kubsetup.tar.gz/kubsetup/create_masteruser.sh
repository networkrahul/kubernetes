#!/bin/bash
echo "Adding user master -> Give password -> rest options leave default"
adduser master # Give password
usermod -aG sudo master
cp ./as_masteruser.sh /home/master
chmod +x /home/master/as_masteruser.sh
